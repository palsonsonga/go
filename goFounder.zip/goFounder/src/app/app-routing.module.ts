import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContentComponent } from './layout/content/content.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';


const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  {
    path: '', component: ContentComponent, children: [
      { path: 'dashboard', component: DashboardComponent ,data:{ breadcrumb:'Dashboard'
    }},
      { path: 'updates', loadChildren: () => import('./modules/updates/updates.module').then(m => m.UpdatesModule) ,data:{ breadcrumb:'Updates'
    }}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
