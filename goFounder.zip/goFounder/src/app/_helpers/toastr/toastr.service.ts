import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class ToasterService {
  constructor(private toastr: ToastrService) { }
  /**
   * @param {string} [type]
   * @param {string} [title]
   * @param {string} [message]
   * @memberof ToasterService
   */
  show(type?: string, title?: string, message?: string) {
    if (message || title) {
      if (title) {
        if (type === 'error') {
          if(typeof title === 'object'){
            var obj = JSON.parse(JSON.stringify(title));
            var keys = Object.keys(obj);
            keys.forEach(item => {
              this.toastr.error(obj[item], message);
            });
          }
          else this.toastr.error(title, message);
        } else if (type === 'success') {
          if(title == 'Success' || title == 'success'){}
          else this.toastr.success(title, message);
        }else if (type === 'info') {
           this.toastr.info(title, message);
        } else {
          this.toastr.warning(title, message);
        }
      }
    }
  }
  /**
   *
   * @description clears all toasts
   * @memberof ToasterService
   */
  clearAll() {
    // this.messageService.clear();
  }
}
