import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { LocalstorageService } from './localstorage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private _ls : LocalstorageService){}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      var url = route['_routerState'].url.toString();
      console.log(url);
        return true;
    if (this._ls.isLoggedIn()) {
      // TODO : role based authentication
      return true;
    } else {
      //this._router.navigate(['/login']);
     return true
     // return false;
    }
  }
  
}
