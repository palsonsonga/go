import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpdatesComponent } from './updates/updates.component';
import { RouterModule, Routes } from '@angular/router';

const routes:Routes =[
  {path:'',component:UpdatesComponent}
]

@NgModule({
  declarations: [UpdatesComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports:[ RouterModule ]
})
export class UpdatesModule { }
