import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd} from '@angular/router';
import { filter} from 'rxjs/operators';

@Component({
  selector: 'app-top-nav',
  templateUrl: './top-nav.component.html',
  styleUrls: ['./top-nav.component.scss']
})
export class TopNavComponent implements OnInit {
title
url
  constructor( private _ar :ActivatedRoute , private router :Router) {
    this.breadcrumb()
   }

  ngOnInit(): void {
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(res=>{
      let data:any =res
      this.url=data.urlAfterRedirects 
    this.breadcrumb()
  })
  }
  breadcrumb(){
    this._ar.children[0].data.subscribe(data=>{
      this.title =data['breadcrumb'] 
})
  }

}
