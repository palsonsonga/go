import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.scss']
})
export class ContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  mode() {
    if (window.innerWidth > 990) return 'side'
       else return 'over'
  }
  backDrop() {
    if (window.innerWidth > 990) return false
      else return true
  }
open(){
  if(window.innerWidth > 990) return true
  else return false
}
position(){
  if (window.innerWidth > 990) return 'start'
  else return 'end'
}

}
