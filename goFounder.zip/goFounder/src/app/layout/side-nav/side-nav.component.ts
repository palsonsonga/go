import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {

  constructor() { }
  menuItems = [
    { title: 'Dashboard', path: '/dashboard', icon: 'fa fa-tachometer', children: [], showSubMenu: false }, 
    { title: 'Updates', path: '/updates', icon: 'fa fa-tachometer', children: [], showSubMenu: false }, 
    {title: 'Inbox', path: '/inbox', icon: 'fa fa-inbox',children: [],showSubMenu: false}
  ];
  ngOnInit(): void {
  }

}
